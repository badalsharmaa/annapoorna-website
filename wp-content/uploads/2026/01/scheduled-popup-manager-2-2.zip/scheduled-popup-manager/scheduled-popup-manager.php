<?php
/**
 * Plugin Name: HD Popup
 * Plugin URI: https://hiraya.digital
 * Description: Professional popup manager with calendar-based scheduling, image sliders, and custom HTML support
 * Version: 1.0.3
 * Author: Rajesh Kumar
 * Author URI: https://hiraya.digital
 * License: GPL v2 or later
 * Text Domain: scheduled-popup-manager
 */

if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('SPM_VERSION', '1.0.3');
define('SPM_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('SPM_PLUGIN_URL', plugin_dir_url(__FILE__));

// Include required files
require_once SPM_PLUGIN_DIR . 'includes/class-popup-manager.php';
require_once SPM_PLUGIN_DIR . 'includes/class-scheduler.php';

class Scheduled_Popup_Manager {

    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Activation hook
        register_activation_hook(__FILE__, array($this, 'activate'));

        // Initialize plugin
        add_action('init', array($this, 'init'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_assets'));
        add_action('wp_footer', array($this, 'display_scheduled_popup'));

        // AJAX handlers
        add_action('wp_ajax_spm_save_popup', array($this, 'ajax_save_popup'));
        add_action('wp_ajax_spm_delete_popup', array($this, 'ajax_delete_popup'));
        add_action('wp_ajax_spm_get_popups', array($this, 'ajax_get_popups'));
        add_action('wp_ajax_spm_save_schedule', array($this, 'ajax_save_schedule'));
        add_action('wp_ajax_spm_get_schedule', array($this, 'ajax_get_schedule'));
        add_action('wp_ajax_spm_delete_schedule', array($this, 'ajax_delete_schedule'));
        
        // Frontend AJAX
        add_action('wp_ajax_spm_get_current_popup', array($this, 'ajax_get_current_popup'));
        add_action('wp_ajax_nopriv_spm_get_current_popup', array($this, 'ajax_get_current_popup'));
    }

    public function activate() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        // Create popups table
        $table_name = $wpdb->prefix . 'spm_popups';
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            name varchar(255) NOT NULL,
            type varchar(50) NOT NULL,
            content longtext NOT NULL,
            settings longtext NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        // Create schedule table
        $table_schedule = $wpdb->prefix . 'spm_schedule';
        $sql2 = "CREATE TABLE IF NOT EXISTS $table_schedule (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            popup_id mediumint(9) NOT NULL,
            schedule_date date NOT NULL,
            is_active tinyint(1) DEFAULT 1,
            PRIMARY KEY  (id),
            KEY popup_id (popup_id),
            KEY schedule_date (schedule_date)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        dbDelta($sql2);
    }

    public function init() {
        // Initialize plugin components
    }

    public function add_admin_menu() {
        add_menu_page(
            'Scheduled Popups',
            'Popups',
            'manage_options',
            'scheduled-popup-manager',
            array($this, 'render_admin_page'),
            'dashicons-calendar-alt',
            30
        );
    }

    public function enqueue_admin_assets($hook) {
        if ('toplevel_page_scheduled-popup-manager' !== $hook) {
            return;
        }

        // CSS
        wp_enqueue_style('spm-admin-style', SPM_PLUGIN_URL . 'admin/css/admin-style.css', array(), SPM_VERSION);
        wp_enqueue_style('wp-color-picker');

        // JS
        wp_enqueue_media();
        wp_enqueue_script('wp-color-picker');
        wp_enqueue_script('spm-admin-script', SPM_PLUGIN_URL . 'admin/js/admin-script.js', array('jquery', 'wp-color-picker', 'jquery-ui-sortable'), SPM_VERSION, true);
        wp_enqueue_script('spm-calendar-script', SPM_PLUGIN_URL . 'admin/js/calendar.js', array('jquery'), SPM_VERSION, true);

        wp_localize_script('spm-admin-script', 'spmAdmin', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('spm_nonce'),
            'pluginUrl' => SPM_PLUGIN_URL
        ));
    }

    public function enqueue_frontend_assets() {
        if (!is_front_page()) {
            return;
        }
        wp_enqueue_style('spm-popup-style', SPM_PLUGIN_URL . 'public/css/popup-style.css', array(), SPM_VERSION);
        wp_enqueue_script('spm-popup-script', SPM_PLUGIN_URL . 'public/js/popup-script.js', array('jquery'), SPM_VERSION, true);

        wp_localize_script('spm-popup-script', 'spmPublic', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('spm_frontend_nonce'),
            'action' => 'spm_get_current_popup'
        ));
    }

    public function render_admin_page() {
        include SPM_PLUGIN_DIR . 'admin/views/admin-page.php';
    }

    public function display_scheduled_popup() {
        if (!is_front_page()) {
            return;
        }
        // Placeholder for AJAX loading
        echo '<div id="spm-popup-placeholder" style="display:none;"></div>';
    }

    // AJAX Handlers
    public function ajax_save_popup() {
        check_ajax_referer('spm_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        $manager = new SPM_Popup_Manager();
        $result = $manager->save_popup($_POST);

        if ($result) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error('Failed to save popup');
        }
    }

    public function ajax_delete_popup() {
        check_ajax_referer('spm_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        $manager = new SPM_Popup_Manager();
        $result = $manager->delete_popup($_POST['popup_id']);

        wp_send_json_success();
    }

    public function ajax_get_popups() {
        check_ajax_referer('spm_nonce', 'nonce');

        $manager = new SPM_Popup_Manager();
        $popups = $manager->get_all_popups();

        wp_send_json_success($popups);
    }

    public function ajax_save_schedule() {
        check_ajax_referer('spm_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        $scheduler = new SPM_Scheduler();
        $result = $scheduler->save_schedule($_POST);

        wp_send_json_success($result);
    }

    public function ajax_get_schedule() {
        check_ajax_referer('spm_nonce', 'nonce');

        $scheduler = new SPM_Scheduler();
        $schedule = $scheduler->get_schedule($_POST['month'], $_POST['year']);

        wp_send_json_success($schedule);
    }

    public function ajax_delete_schedule() {
        check_ajax_referer('spm_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        $scheduler = new SPM_Scheduler();
        $result = $scheduler->delete_schedule($_POST['date']);

        wp_send_json_success($result);
    }

    public function ajax_get_current_popup() {
        // Nonce check removed to allow cached pages to fetch popups reliably
        // check_ajax_referer('spm_frontend_nonce', 'nonce');

        $scheduler = new SPM_Scheduler();
        $popup = $scheduler->get_today_popup();

        if ($popup) {
            $manager = new SPM_Popup_Manager();
            $html = $manager->render_popup($popup);
            wp_send_json_success($html);
        } else {
            wp_send_json_error('No popup scheduled');
        }
    }
}

// Initialize plugin
Scheduled_Popup_Manager::get_instance();
