# HD Popup - Professional Popup Scheduling Plugin

**Version:** 1.0.1
**Developer:** Rajesh Kumar
**Company:** Hiraya Digital
**Website:** https://hiraya.digital

## Overview

HD Popup is a professional WordPress plugin that allows you to create, manage, and schedule popups on your website. Perfect for displaying daily specials, weekly promotions, seasonal offers, and time-sensitive announcements.

## Features

### Popup Types
- **Single Image Popups** - Display promotional images
- **Image Sliders** - Showcase multiple images with smooth transitions
- **Custom HTML** - Create complex popups with custom HTML/CSS/JavaScript

### Scheduling System
- **Calendar-based scheduling** - Visual calendar interface for scheduling popups
- **Date-specific popups** - Assign different popups to different dates
- **Perfect for recurring promotions** - Set up weekly specials, daily deals, monthly offers

### Customization Options
- **Multiple transition effects** for sliders (Fade, Slide, Zoom, Flip)
- **Appearance animations** (Fade In, Slide Down/Up/Left/Right, Zoom, Bounce, Flip)
- **Close button customization** - Customize colors and background
- **Image URL linking** - Link popup images to specific URLs
- **Responsive design** - Automatically adjusts for mobile devices

### Trigger Options
- **On Page Load** - Show immediately when page loads
- **After Delay** - Show after specified seconds
- **On Scroll** - Trigger at specific scroll percentage
- **Exit Intent** - Show when user is about to leave
- **On Element Click** - Trigger when specific element is clicked

### Professional Admin Interface
- Modern, clean design with #21409a color scheme
- Intuitive popup creation workflow
- Visual calendar for scheduling
- Easy-to-use drag-and-drop interface

## Installation

1. Upload the `scheduled-popup-manager` folder to `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Navigate to 'Popups' in the admin menu to get started

## Usage

### Creating a Popup

1. Go to **Popups** in the WordPress admin menu
2. Click **Create New Popup**
3. Enter a popup name (e.g., "Monday Special Offer")
4. Select popup type:
   - **Image**: Upload a single image
   - **Slider**: Add multiple images with transitions
   - **HTML**: Enter custom HTML content
5. Configure appearance:
   - Choose animation effect
   - Set close button colors
   - Enable responsive design
6. Set trigger options:
   - Select when popup should appear
   - Configure trigger-specific settings
7. Click **Save Popup**

### Scheduling Popups

1. Go to the **Schedule Calendar** tab
2. Navigate to the desired month/year
3. Click on a date
4. Select a popup from the dropdown
5. Click **Assign**

The selected popup will now display on that date automatically!

### Managing Popups

- **Edit**: Click the Edit button on any popup card to modify it
- **Delete**: Click the Delete button to remove a popup (and its schedules)
- **View**: All your popups are displayed in an organized grid

## Configuration Examples

### Daily Specials Restaurant

Create 7 popups (Monday through Sunday), each with the day's special. Schedule them on the calendar for recurring weekly promotions.

### Seasonal Promotions

Create popups for holidays (Christmas, New Year, Black Friday) and schedule them weeks in advance.

### Product Launches

Create countdown popups or announcement popups scheduled for specific launch dates.

## Technical Details

### Database Tables

The plugin creates two tables:
- `wp_spm_popups` - Stores popup data
- `wp_spm_schedule` - Stores scheduling information

### File Structure

```
scheduled-popup-manager/
├── scheduled-popup-manager.php (Main plugin file)
├── admin/
│   ├── css/admin-style.css (Admin styling)
│   ├── js/admin-script.js (Admin functionality)
│   ├── js/calendar.js (Calendar functionality)
│   └── views/admin-page.php (Admin template)
├── public/
│   ├── css/popup-style.css (Frontend styling)
│   └── js/popup-script.js (Frontend functionality)
└── includes/
    ├── class-popup-manager.php (Popup management)
    └── class-scheduler.php (Scheduling logic)
```

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## Changelog

### Version 1.0.1
- Restricted popups to display only on the home page

### Version 1.0.0
- Initial release
- Image, Slider, and HTML popup types
- Calendar-based scheduling
- Multiple animation and transition effects
- Responsive design support
- Trigger options (on load, delay, scroll, exit intent, click)
- Professional admin interface

## Support

For support, bug reports, or feature requests, please contact:
- **Email:** support@hiraya.digital
- **Website:** https://hiraya.digital

## License

GPL v2 or later

---

**Developed by Rajesh Kumar @ Hiraya Digital**
