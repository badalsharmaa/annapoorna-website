/**
 * HD Popup Manager - Frontend Script
 * Handles popup display, triggers, and animations
 */

(function ($) {
    'use strict';

    let popupShown = false;
    let currentSlide = 0;
    let autoplayInterval = null;

    $(document).ready(function () {
        // Fetch popup content via AJAX
        if (typeof spmPublic === 'undefined') {
            console.error('SPM Error: spmPublic object not found.');
            return;
        }

        console.log('SPM: Fetching popup...', spmPublic.ajaxurl);

        $.ajax({
            url: spmPublic.ajaxurl,
            type: 'POST',
            data: {
                action: spmPublic.action,
                nonce: spmPublic.nonce
            },
            success: function (response) {
                console.log('SPM: Response received', response);
                if (response.success && response.data) {
                    // Append popup HTML to body (or placeholder)
                    $('body').append(response.data);

                    const popup = $('.spm-popup-overlay');
                    if (popup.length > 0) {
                        console.log('SPM: Popup injected, initializing...');
                        initializePopup();
                        detectImageOrientation();
                    } else {
                        console.error('SPM Error: Popup markup not found after injection.');
                    }
                } else {
                    console.log('SPM: No popup returned or success=false.', response);
                }
            },
            error: function (xhr, status, error) {
                console.error('SPM AJAX Error:', status, error);
                console.log('SPM Response Text:', xhr.responseText);
            }
        });
    });

    function detectImageOrientation() {
        const container = $('.spm-popup-container');
        const images = container.find('.spm-popup-content img');

        if (images.length > 0) {
            const img = images.first();

            // Wait for image to load
            if (img[0].complete) {
                applyOrientation(img[0], container);
            } else {
                img.on('load', function () {
                    applyOrientation(this, container);
                });
            }
        }
    }

    function applyOrientation(img, container) {
        const width = img.naturalWidth;
        const height = img.naturalHeight;

        if (height > width) {
            // Portrait orientation
            container.addClass('spm-portrait');
            container.removeClass('spm-landscape');
        } else {
            // Landscape orientation
            container.addClass('spm-landscape');
            container.removeClass('spm-portrait');
        }
    }

    function initializePopup() {
        const popup = $('.spm-popup-overlay');
        const container = $('.spm-popup-container');

        // Get popup settings from data attributes or defaults
        const settings = getPopupSettings(container);

        // Apply responsive class
        if (settings.responsive) {
            container.addClass('responsive');
        }

        // Initialize slider if it's a slider popup
        if (container.data('type') === 'slider') {
            initializeSlider(settings);
        }

        // Setup trigger
        setupTrigger(settings);

        // Setup close handlers
        setupCloseHandlers(settings);
    }

    function getPopupSettings(container) {
        // Settings would ideally be passed via data attributes
        // For now, using defaults that can be overridden
        return {
            animation: container.data('animation') || 'fade',
            animationDuration: container.data('animation-duration') || 500,
            trigger: container.data('trigger') || 'onload',
            triggerDelay: container.data('trigger-delay') || 3,
            triggerScroll: container.data('trigger-scroll') || 50,
            triggerSelector: container.data('trigger-selector') || '',
            responsive: container.data('responsive') !== false,
            closeOutside: container.data('close-outside') !== false
        };
    }

    function setupTrigger(settings) {
        switch (settings.trigger) {
            case 'onload':
                setTimeout(function () {
                    showPopup(settings);
                }, 100);
                break;

            case 'delay':
                setTimeout(function () {
                    showPopup(settings);
                }, settings.triggerDelay * 1000);
                break;

            case 'scroll':
                $(window).on('scroll', function () {
                    if (popupShown) return;

                    const scrollPercent = ($(window).scrollTop() / ($(document).height() - $(window).height())) * 100;

                    if (scrollPercent >= settings.triggerScroll) {
                        showPopup(settings);
                        popupShown = true;
                    }
                });
                break;

            case 'exit':
                $(document).on('mouseleave', function (e) {
                    if (popupShown) return;

                    if (e.clientY <= 0) {
                        showPopup(settings);
                        popupShown = true;
                    }
                });
                break;

            case 'click':
                if (settings.triggerSelector) {
                    $(document).on('click', settings.triggerSelector, function (e) {
                        e.preventDefault();
                        showPopup(settings);
                    });
                }
                break;
        }
    }

    function showPopup(settings) {
        const overlay = $('.spm-popup-overlay');
        const container = $('.spm-popup-container');

        // Apply animation
        applyAnimation(container, settings.animation, settings.animationDuration);

        // Show overlay
        overlay.addClass('active');
        overlay.css('animation', 'fadeIn ' + (settings.animationDuration / 1000) + 's ease');

        setTimeout(function () {
            overlay.css('opacity', '1');
        }, 10);

        // Prevent body scroll
        $('body').css('overflow', 'hidden');
    }

    function applyAnimation(element, animation, duration) {
        const animationCSS = animation + ' ' + (duration / 1000) + 's ease';
        element.css('animation', animationCSS);
    }

    function hidePopup() {
        const overlay = $('.spm-popup-overlay');

        overlay.css('opacity', '0');

        setTimeout(function () {
            overlay.removeClass('active');
            $('body').css('overflow', '');
        }, 300);

        // Stop slider autoplay
        if (autoplayInterval) {
            clearInterval(autoplayInterval);
        }
    }

    function setupCloseHandlers(settings) {
        // Close button
        $('.spm-close-btn').on('click', function (e) {
            e.stopPropagation();
            hidePopup();
        });

        // Close on outside click
        if (settings.closeOutside) {
            $('.spm-popup-overlay').on('click', function (e) {
                if ($(e.target).hasClass('spm-popup-overlay')) {
                    hidePopup();
                }
            });
        }

        // Close on ESC key
        $(document).on('keydown', function (e) {
            if (e.key === 'Escape' && $('.spm-popup-overlay').hasClass('active')) {
                hidePopup();
            }
        });
    }

    function initializeSlider(settings) {
        // Find slider within the specific popup container
        const container = $('.spm-popup-container');
        const slider = container.find('.spm-slider-popup');

        if (slider.length === 0) return;

        const track = slider.find('.spm-slider-track');
        const slides = track.find('.spm-slide');
        let totalSlides = slides.length;

        if (totalSlides <= 1) {
            slider.find('.spm-slider-prev, .spm-slider-next, .spm-slider-dots').hide();
            return;
        }

        const autoplay = slider.data('autoplay') !== false;
        const interval = parseInt(slider.data('interval')) || 3000;
        
        // Clone first and last slides for infinite loop
        const firstClone = slides.first().clone();
        const lastClone = slides.last().clone();
        
        track.append(firstClone);
        track.prepend(lastClone);
        
        // Update total slides count (including clones)
        const allSlides = track.find('.spm-slide');
        
        let slideIndex = 1; // Start at 1 because of prepended clone
        let isTransitioning = false;
        
        // Initialize position
        updateTrackPosition(false);

        // Next slide
        slider.find('.spm-slider-next').on('click', function (e) {
            e.stopPropagation();
            moveNext();
        });

        // Previous slide
        slider.find('.spm-slider-prev').on('click', function (e) {
            e.stopPropagation();
            movePrev();
        });

        // Dot navigation
        slider.find('.spm-dot').on('click', function (e) {
            e.stopPropagation();
            if (isTransitioning) return;
            const index = $(this).data('slide');
            slideIndex = index + 1; // Adjust for clone
            updateTrackPosition(true);
            updateDots();
        });

        // Autoplay
        if (autoplay) {
            startAutoplay();
            
            // Pause on hover
            slider.on('mouseenter', stopAutoplay);
            slider.on('mouseleave', startAutoplay);
        }

        function startAutoplay() {
            if (autoplayInterval) clearInterval(autoplayInterval);
            autoplayInterval = setInterval(function () {
                moveNext();
            }, interval);
        }

        function stopAutoplay() {
            if (autoplayInterval) {
                clearInterval(autoplayInterval);
                autoplayInterval = null;
            }
        }
        
        function moveNext() {
            if (isTransitioning) return;
            if (slideIndex >= allSlides.length - 1) return; // Safety
            
            slideIndex++;
            updateTrackPosition(true);
            updateDots();
        }
        
        function movePrev() {
            if (isTransitioning) return;
            if (slideIndex <= 0) return; // Safety
            
            slideIndex--;
            updateTrackPosition(true);
            updateDots();
        }
        
        function updateTrackPosition(transition) {
            isTransitioning = true;
            
            if (transition) {
                track.css('transition', 'transform 0.5s ease-in-out');
            } else {
                track.css('transition', 'none');
            }
            
            const translateX = -(slideIndex * 100);
            track.css('transform', 'translateX(' + translateX + '%)');
            
            // Check for loop reset after transition
            if (transition) {
                track.one('transitionend', function() {
                    isTransitioning = false;
                    
                    // Loop Logic
                    if (slideIndex === allSlides.length - 1) {
                        // We are at the cloned first slide, jump to real first slide
                        slideIndex = 1;
                        track.css('transition', 'none');
                        track.css('transform', 'translateX(-100%)');
                    } else if (slideIndex === 0) {
                        // We are at the cloned last slide, jump to real last slide
                        slideIndex = allSlides.length - 2;
                        track.css('transition', 'none');
                        track.css('transform', 'translateX(' + (-(slideIndex * 100)) + '%)');
                    }
                });
            } else {
                isTransitioning = false;
            }
        }
        
        function updateDots() {
            let realIndex = slideIndex - 1;
            if (realIndex < 0) realIndex = totalSlides - 1;
            if (realIndex >= totalSlides) realIndex = 0;
            
            slider.find('.spm-dot').removeClass('active');
            slider.find('.spm-dot[data-slide="' + realIndex + '"]').addClass('active');
        }

        // Swipe support
        let touchStartX = 0;
        let touchEndX = 0;

        slider.on('touchstart', function (e) {
            touchStartX = e.touches[0].clientX;
            stopAutoplay();
        });

        slider.on('touchend', function (e) {
            touchEndX = e.changedTouches[0].clientX;
            handleSwipe();
            if (autoplay) startAutoplay();
        });

        function handleSwipe() {
            if (touchEndX < touchStartX - 50) {
                moveNext();
            }
            if (touchEndX > touchStartX + 50) {
                movePrev();
            }
        }
    }

    // Make functions globally accessible
    window.SPMPopup = {
        show: function () {
            const settings = getPopupSettings($('.spm-popup-container'));
            showPopup(settings);
        },
        hide: hidePopup
    };

})(jQuery);
