<?php
/**
 * Scheduler Class
 * Handles popup scheduling and calendar management
 */

if (!defined('ABSPATH')) {
    exit;
}

class SPM_Scheduler {

    private $table_name;
    private $popup_table;

    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'spm_schedule';
        $this->popup_table = $wpdb->prefix . 'spm_popups';
    }

    /**
     * Save schedule
     */
    public function save_schedule($data) {
        global $wpdb;

        $popup_id = intval($data['popup_id']);
        $date = sanitize_text_field($data['date']);

        // Check if schedule already exists for this date
        $existing = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM {$this->table_name} WHERE schedule_date = %s",
                $date
            )
        );

        if ($existing) {
            // Update existing schedule
            $wpdb->update(
                $this->table_name,
                array('popup_id' => $popup_id, 'is_active' => 1),
                array('schedule_date' => $date)
            );
        } else {
            // Create new schedule
            $wpdb->insert(
                $this->table_name,
                array(
                    'popup_id' => $popup_id,
                    'schedule_date' => $date,
                    'is_active' => 1
                )
            );
        }

        return true;
    }

    /**
     * Delete schedule for a specific date
     */
    public function delete_schedule($date) {
        global $wpdb;

        return $wpdb->delete(
            $this->table_name,
            array('schedule_date' => sanitize_text_field($date))
        );
    }

    /**
     * Get schedule for a specific month/year
     */
    public function get_schedule($month, $year) {
        global $wpdb;

        $start_date = sprintf('%04d-%02d-01', $year, $month);
        $end_date = date('Y-m-t', strtotime($start_date));

        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT s.*, p.name as popup_name
                FROM {$this->table_name} s
                LEFT JOIN {$this->popup_table} p ON s.popup_id = p.id
                WHERE s.schedule_date BETWEEN %s AND %s
                AND s.is_active = 1",
                $start_date,
                $end_date
            ),
            ARRAY_A
        );

        return $results;
    }

    /**
     * Get today's scheduled popup
     */
    public function get_today_popup() {
        global $wpdb;

        // Get all popups to check scheduling
        $all_popups = $wpdb->get_results(
            "SELECT * FROM {$this->popup_table} ORDER BY id DESC",
            ARRAY_A
        );

        foreach ($all_popups as $popup) {
            $settings = json_decode($popup['settings'], true);
            $schedule = isset($settings['schedule']) ? $settings['schedule'] : array('type' => 'manual');
            
            // Determine timezone
            $timezone_string = !empty($schedule['timezone']) ? $schedule['timezone'] : get_option('timezone_string');
            if (empty($timezone_string)) {
                $gmt_offset = get_option('gmt_offset');
                $timezone_string = timezone_name_from_abbr('', $gmt_offset * 3600, false);
                if (false === $timezone_string) {
                    $timezone_string = 'UTC';
                }
            }

            try {
                $dt = new DateTime('now', new DateTimeZone($timezone_string));
                $today = $dt->format('Y-m-d');
                $day_of_week = $dt->format('w');
            } catch (Exception $e) {
                // Fallback to server time if timezone is invalid
                $today = current_time('Y-m-d');
                $day_of_week = date('w', strtotime($today));
            }

            switch ($schedule['type']) {
                case 'always':
                    // Always active - return this popup
                    return $popup;

                case 'daterange':
                    // Check if today is within the date range
                    if (isset($schedule['start_date']) && isset($schedule['end_date'])) {
                        $start = $schedule['start_date'];
                        $end = $schedule['end_date'];

                        if ($today >= $start && $today <= $end) {
                            return $popup;
                        }
                    }
                    break;

                case 'daysofweek':
                    // Check if today's day of week matches
                    if (isset($schedule['days'])) {
                        $days = explode(',', $schedule['days']);
                        if (in_array((string)$day_of_week, $days)) {
                            return $popup;
                        }
                    }
                    break;

                case 'manual':
                    // Check manual calendar schedule
                    // Note: Manual schedule table stores dates as Y-m-d, so we compare against our timezone-adjusted $today
                    $manual_popup = $wpdb->get_row(
                        $wpdb->prepare(
                            "SELECT p.*
                            FROM {$this->popup_table} p
                            INNER JOIN {$this->table_name} s ON p.id = s.popup_id
                            WHERE p.id = %d
                            AND s.schedule_date = %s
                            AND s.is_active = 1
                            LIMIT 1",
                            $popup['id'],
                            $today
                        ),
                        ARRAY_A
                    );

                    if ($manual_popup) {
                        return $manual_popup;
                    }
                    break;
            }
        }

        return null;
    }

    /**
     * Get all schedules for a popup
     */
    public function get_popup_schedules($popup_id) {
        global $wpdb;

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$this->table_name} WHERE popup_id = %d AND is_active = 1",
                $popup_id
            ),
            ARRAY_A
        );
    }
}
