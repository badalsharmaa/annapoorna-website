<?php
/**
 * Popup Manager Class
 * Handles popup creation, editing, and management
 */

if (!defined('ABSPATH')) {
    exit;
}

class SPM_Popup_Manager {

    private $table_name;

    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'spm_popups';
    }

    /**
     * Save or update a popup
     */
    public function save_popup($data) {
        global $wpdb;

        error_log('SPM: Saving popup data: ' . print_r($data, true));

        $content = '';
        if ($data['type'] === 'slider') {
            // Handle JSON content for slider
            $raw_content = stripslashes($data['content']);
            error_log('SPM: Raw slider content: ' . $raw_content);
            
            $slides = json_decode($raw_content, true);
            if (is_array($slides)) {
                foreach ($slides as &$slide) {
                    $slide['url'] = esc_url_raw($slide['url']);
                    $slide['link'] = esc_url_raw($slide['link']);
                    if (isset($slide['schedule'])) {
                        $slide['schedule']['type'] = sanitize_text_field($slide['schedule']['type']);
                        $slide['schedule']['start'] = sanitize_text_field($slide['schedule']['start']);
                        $slide['schedule']['end'] = sanitize_text_field($slide['schedule']['end']);
                    }
                }
                $content = json_encode($slides);
            } else {
                error_log('SPM: Failed to decode slides JSON: ' . json_last_error_msg());
            }
        } elseif ($data['type'] === 'image') {
            $content = esc_url_raw($data['content']);
        } else {
            // Default to HTML/Text
            $content = wp_kses_post($data['content']);
        }

        $popup_data = array(
            'name' => sanitize_text_field($data['name']),
            'type' => sanitize_text_field($data['type']),
            'content' => $content,
            'settings' => json_encode($data['settings'])
        );

        if (isset($data['popup_id']) && $data['popup_id'] > 0) {
            // Update existing popup
            $wpdb->update(
                $this->table_name,
                $popup_data,
                array('id' => intval($data['popup_id']))
            );
            return intval($data['popup_id']);
        } else {
            // Create new popup
            $wpdb->insert($this->table_name, $popup_data);
            return $wpdb->insert_id;
        }
    }

    /**
     * Get all popups
     */
    public function get_all_popups() {
        global $wpdb;

        $results = $wpdb->get_results(
            "SELECT * FROM {$this->table_name} ORDER BY created_at DESC",
            ARRAY_A
        );

        foreach ($results as &$popup) {
            $popup['settings'] = json_decode($popup['settings'], true);
        }

        return $results;
    }

    /**
     * Get single popup by ID
     */
    public function get_popup($popup_id) {
        global $wpdb;

        $popup = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table_name} WHERE id = %d", $popup_id),
            ARRAY_A
        );

        if ($popup) {
            $popup['settings'] = json_decode($popup['settings'], true);
        }

        return $popup;
    }

    /**
     * Delete popup
     */
    public function delete_popup($popup_id) {
        global $wpdb;

        // Also delete associated schedules
        $schedule_table = $wpdb->prefix . 'spm_schedule';
        $wpdb->delete($schedule_table, array('popup_id' => intval($popup_id)));

        // Delete popup
        return $wpdb->delete($this->table_name, array('id' => intval($popup_id)));
    }

    /**
     * Render popup HTML
     */
    public function render_popup($popup) {
        $settings = is_string($popup['settings']) ? json_decode($popup['settings'], true) : $popup['settings'];

        $html = '<div id="spm-popup-overlay" class="spm-popup-overlay">';

        // Build data attributes for settings
        $data_attrs = array(
            'data-type' => $popup['type'],
            'data-animation' => isset($settings['animation']) ? $settings['animation'] : 'fade',
            'data-animation-duration' => isset($settings['animation_duration']) ? $settings['animation_duration'] : '500',
            'data-trigger' => isset($settings['trigger']) ? $settings['trigger'] : 'onload',
            'data-trigger-delay' => isset($settings['trigger_delay']) ? $settings['trigger_delay'] : '3',
            'data-trigger-scroll' => isset($settings['trigger_scroll']) ? $settings['trigger_scroll'] : '50',
            'data-trigger-selector' => isset($settings['trigger_selector']) ? $settings['trigger_selector'] : '',
            'data-responsive' => isset($settings['responsive']) && $settings['responsive'] ? 'true' : 'false',
            'data-close-outside' => isset($settings['close_outside']) && $settings['close_outside'] ? 'true' : 'false'
        );

        $attrs_string = '';
        foreach ($data_attrs as $key => $value) {
            $attrs_string .= ' ' . $key . '="' . esc_attr($value) . '"';
        }

        // Build inline styles for size/scale
        $max_width = isset($settings['max_width']) ? $settings['max_width'] : '90vw';
        $max_height = isset($settings['max_height']) ? $settings['max_height'] : '90vh';
        $content_fit = isset($settings['content_fit']) ? $settings['content_fit'] : 'contain';
        $scale = isset($settings['scale']) ? floatval($settings['scale']) / 100 : 1;

        $container_styles = 'max-width: ' . esc_attr($max_width) . '; max-height: ' . esc_attr($max_height) . ';';
        if ($scale != 1) {
            $container_styles .= ' transform: scale(' . esc_attr($scale) . ');';
        }

        $html .= '<div class="spm-popup-container" style="' . $container_styles . '"' . $attrs_string . ' data-content-fit="' . esc_attr($content_fit) . '">';

        // Close button
        $close_bg = isset($settings['close_bg']) ? $settings['close_bg'] : '#21409a';
        $close_color = isset($settings['close_color']) ? $settings['close_color'] : '#ffffff';
        $html .= '<button class="spm-close-btn" style="background-color: ' . esc_attr($close_bg) . '; color: ' . esc_attr($close_color) . ';">&times;</button>';

        // Popup content based on type
        switch ($popup['type']) {
            case 'image':
                $html .= $this->render_image_popup($popup, $settings);
                break;
            case 'slider':
                $html .= $this->render_slider_popup($popup, $settings);
                break;
            case 'html':
                $html .= $this->render_html_popup($popup, $settings);
                break;
        }

        $html .= '</div></div>';

        return $html;
    }

    private function render_image_popup($popup, $settings) {
        $image_url = $popup['content'];
        $link_url = isset($settings['link_url']) ? $settings['link_url'] : '';
        $content_fit = isset($settings['content_fit']) ? $settings['content_fit'] : 'contain';

        $html = '<div class="spm-popup-content spm-image-popup">';

        if ($link_url) {
            $html .= '<a href="' . esc_url($link_url) . '" target="_blank">';
        }

        $html .= '<img src="' . esc_url($image_url) . '" alt="Popup Image" style="object-fit: ' . esc_attr($content_fit) . ';" />';

        if ($link_url) {
            $html .= '</a>';
        }

        $html .= '</div>';

        return $html;
    }

    private function render_slider_popup($popup, $settings) {
        $images = json_decode($popup['content'], true);
        if (!is_array($images)) {
            return ''; // Return empty if content is invalid
        }

        // Filter slides based on schedule
        $active_images = array();
        $today = date('Y-m-d');
        
        foreach ($images as $image) {
            $show = true;
            if (isset($image['schedule']) && $image['schedule']['type'] === 'custom') {
                $start = $image['schedule']['start'];
                $end = $image['schedule']['end'];
                
                if ($start && $today < $start) {
                    $show = false;
                }
                if ($end && $today > $end) {
                    $show = false;
                }
            }
            
            if ($show) {
                $active_images[] = $image;
            }
        }
        
        if (empty($active_images)) {
            return '';
        }

        $transition = isset($settings['transition']) ? $settings['transition'] : 'fade';
        $autoplay = isset($settings['autoplay']) ? $settings['autoplay'] : true;
        $interval = isset($settings['interval']) ? $settings['interval'] : 3000;
        $content_fit = isset($settings['content_fit']) ? $settings['content_fit'] : 'contain';

        $html = '<div class="spm-popup-content spm-slider-popup" data-transition="' . esc_attr($transition) . '" data-autoplay="' . esc_attr($autoplay) . '" data-interval="' . esc_attr($interval) . '">';
        $html .= '<div class="spm-slider-container">';
        $html .= '<div class="spm-slider-track">';

        foreach ($active_images as $index => $image) {
            $active = $index === 0 ? ' active' : '';
            $link_url = isset($image['link']) ? $image['link'] : '';

            $html .= '<div class="spm-slide' . $active . '">';

            if ($link_url) {
                $html .= '<a href="' . esc_url($link_url) . '" target="_blank">';
            }

            $html .= '<img src="' . esc_url($image['url']) . '" alt="Slide ' . ($index + 1) . '" style="object-fit: ' . esc_attr($content_fit) . ';" />';

            if ($link_url) {
                $html .= '</a>';
            }

            $html .= '</div>';
        }
        
        $html .= '</div>'; // End track
        $html .= '</div>'; // End container

        // Navigation
        if (count($active_images) > 1) {
            $html .= '<button class="spm-slider-prev">&#10094;</button>';
            $html .= '<button class="spm-slider-next">&#10095;</button>';
            $html .= '<div class="spm-slider-dots">';
            foreach ($active_images as $index => $image) {
                $active = $index === 0 ? ' active' : '';
                $html .= '<span class="spm-dot' . $active . '" data-slide="' . $index . '"></span>';
            }
            $html .= '</div>';
        }

        $html .= '</div>';

        return $html;
    }

    private function render_html_popup($popup, $settings) {
        $html = '<div class="spm-popup-content spm-html-popup">';
        $html .= wp_kses_post($popup['content']);
        $html .= '</div>';

        return $html;
    }
}
