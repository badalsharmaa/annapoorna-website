/**
 * HD Popup Manager - Calendar Script
 * Handles popup scheduling calendar
 */

(function($) {
    'use strict';

    let currentMonth = new Date().getMonth();
    let currentYear = new Date().getFullYear();
    let scheduleData = {};

    const monthNames = [
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'
    ];

    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

    $(document).ready(function() {
        init();
    });

    function init() {
        setupEventListeners();
        renderCalendar();
        loadSchedule();
    }

    function setupEventListeners() {
        $('#spm-prev-month').on('click', function() {
            currentMonth--;
            if (currentMonth < 0) {
                currentMonth = 11;
                currentYear--;
            }
            renderCalendar();
            loadSchedule();
        });

        $('#spm-next-month').on('click', function() {
            currentMonth++;
            if (currentMonth > 11) {
                currentMonth = 0;
                currentYear++;
            }
            renderCalendar();
            loadSchedule();
        });

        $('#spm-save-schedule').on('click', function() {
            saveSchedule();
        });

        $(document).on('click', '.spm-calendar-day:not(.other-month)', function() {
            const date = $(this).data('date');
            openScheduleModal(date);
        });
    }

    function renderCalendar() {
        const firstDay = new Date(currentYear, currentMonth, 1).getDay();
        const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
        const daysInPrevMonth = new Date(currentYear, currentMonth, 0).getDate();

        $('#spm-current-month').text(monthNames[currentMonth] + ' ' + currentYear);

        let html = '';

        // Day headers
        dayNames.forEach(function(day) {
            html += '<div class="spm-calendar-day-header">' + day + '</div>';
        });

        // Previous month days
        for (let i = firstDay - 1; i >= 0; i--) {
            const day = daysInPrevMonth - i;
            html += '<div class="spm-calendar-day other-month"><div class="spm-calendar-day-number">' + day + '</div></div>';
        }

        // Current month days
        const today = new Date();
        for (let day = 1; day <= daysInMonth; day++) {
            const date = formatDate(currentYear, currentMonth + 1, day);
            const isToday = (day === today.getDate() && currentMonth === today.getMonth() && currentYear === today.getFullYear());
            const todayClass = isToday ? ' today' : '';

            html += '<div class="spm-calendar-day' + todayClass + '" data-date="' + date + '">';
            html += '<div class="spm-calendar-day-number">' + day + '</div>';
            html += '<div class="spm-calendar-day-popup" data-date="' + date + '"></div>';
            html += '</div>';
        }

        // Next month days
        const totalCells = Math.ceil((firstDay + daysInMonth) / 7) * 7;
        const remainingCells = totalCells - (firstDay + daysInMonth);
        for (let day = 1; day <= remainingCells; day++) {
            html += '<div class="spm-calendar-day other-month"><div class="spm-calendar-day-number">' + day + '</div></div>';
        }

        $('#spm-calendar').html(html);
    }

    function loadSchedule() {
        $.ajax({
            url: spmAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'spm_get_schedule',
                nonce: spmAdmin.nonce,
                month: currentMonth + 1,
                year: currentYear
            },
            success: function(response) {
                if (response.success) {
                    scheduleData = {};
                    response.data.forEach(function(item) {
                        scheduleData[item.schedule_date] = item;
                    });
                    updateCalendarWithSchedule();
                }
            }
        });
    }

    function updateCalendarWithSchedule() {
        $('.spm-calendar-day').removeClass('has-popup');
        $('.spm-calendar-day-popup').text('');

        Object.keys(scheduleData).forEach(function(date) {
            const schedule = scheduleData[date];
            const dayElement = $('.spm-calendar-day[data-date="' + date + '"]');

            if (dayElement.length) {
                dayElement.addClass('has-popup');
                dayElement.find('.spm-calendar-day-popup').text(schedule.popup_name);
            }
        });
    }

    function openScheduleModal(date) {
        $('#spm-schedule-date').val(date);

        // Pre-select popup if one is already scheduled
        if (scheduleData[date]) {
            $('#spm-schedule-popup').val(scheduleData[date].popup_id);
        } else {
            $('#spm-schedule-popup').val('');
        }

        $('#spm-schedule-modal').addClass('active');
        $('body').css('overflow', 'hidden');
    }

    function saveSchedule() {
        const date = $('#spm-schedule-date').val();
        const popupId = $('#spm-schedule-popup').val();

        if (!popupId) {
            // If no popup selected, delete the schedule
            deleteSchedule(date);
            return;
        }

        $.ajax({
            url: spmAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'spm_save_schedule',
                nonce: spmAdmin.nonce,
                popup_id: popupId,
                date: date
            },
            success: function(response) {
                if (response.success) {
                    $('#spm-schedule-modal').removeClass('active');
                    $('body').css('overflow', '');
                    loadSchedule();
                    alert('Schedule saved successfully!');
                }
            }
        });
    }

    function deleteSchedule(date) {
        $.ajax({
            url: spmAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'spm_delete_schedule',
                nonce: spmAdmin.nonce,
                date: date
            },
            success: function(response) {
                $('#spm-schedule-modal').removeClass('active');
                $('body').css('overflow', '');
                loadSchedule();
                alert('Schedule removed successfully!');
            }
        });
    }

    function formatDate(year, month, day) {
        return year + '-' + String(month).padStart(2, '0') + '-' + String(day).padStart(2, '0');
    }

    // Make calendar accessible globally
    window.SPMCalendar = {
        init: init,
        renderCalendar: renderCalendar,
        loadSchedule: loadSchedule
    };

})(jQuery);
