/**
 * HD Popup Manager - Admin JavaScript
 * Handles all admin interface interactions
 */

(function ($) {
    'use strict';

    let currentPopupId = null;
    let allPopups = [];
    let mediaUploader = null;

    $(document).ready(function () {
        initializeTabs();
        initializeColorPickers();
        initializePopupForm();
        initializeModal();
        loadPopups();

        // Load calendar when schedule tab is activated
        $(document).on('click', '.spm-tab-btn[data-tab="schedule"]', function () {
            if ($('#spm-calendar').is(':empty')) {
                initializeCalendar();
            }
        });
    });

    /**
     * Initialize tab switching
     */
    function initializeTabs() {
        $('.spm-tab-btn').on('click', function () {
            const tab = $(this).data('tab');

            $('.spm-tab-btn').removeClass('active');
            $(this).addClass('active');

            $('.spm-tab-content').removeClass('active');
            $('#tab-' + tab).addClass('active');
        });
    }

    /**
     * Initialize color pickers
     */
    function initializeColorPickers() {
        if ($.fn.wpColorPicker) {
            $('.spm-color-picker').wpColorPicker();
        }
    }

    /**
     * Initialize popup form interactions
     */
    function initializePopupForm() {
        // Popup type switching
        $('input[name="popup-type"]').on('change', function () {
            const type = $(this).val();
            $('.spm-content-section').hide();
            $('#content-' + type).show();
        });

        // Trigger type switching
        $('#spm-trigger').on('change', function () {
            const trigger = $(this).val();
            $('.spm-trigger-option').hide();

            if (trigger === 'delay') {
                $('#trigger-delay').show();
            } else if (trigger === 'scroll') {
                $('#trigger-scroll').show();
            } else if (trigger === 'click') {
                $('#trigger-click').show();
            }
        });

        // Image upload
        $('#spm-upload-image').on('click', function (e) {
            e.preventDefault();
            openMediaUploader(function (url) {
                $('#spm-image-url').val(url);
                $('#spm-image-preview').html('<img src="' + url + '">').addClass('active');
            });
        });

        // Initialize sortable
        $('#spm-slides-container').sortable({
            placeholder: "ui-state-highlight",
            handle: ".spm-slide-preview",
            axis: "y"
        });

        // Add slide
        $('#spm-add-slide').on('click', function (e) {
            e.preventDefault();
            openMediaUploader(function (url) {
                addSlideItem(url);
            });
        });

        // Create new popup
        $('#spm-create-popup').on('click', function () {
            currentPopupId = null;
            resetPopupForm();
            openModal('#spm-modal');
            $('#spm-modal-title').text('Create New Popup');
        });

        // Save popup
        $('#spm-save-popup').on('click', function () {
            savePopup();
        });

        // Custom dimensions toggle
        $('#spm-max-width, #spm-max-height').on('change', function () {
            const widthVal = $('#spm-max-width').val();
            const heightVal = $('#spm-max-height').val();

            if (widthVal === 'custom' || heightVal === 'custom') {
                $('#custom-dimensions').show();
            } else {
                $('#custom-dimensions').hide();
            }
        });

        // Preview popup
        $('#spm-preview-popup').on('click', function () {
            showPreview();
        });

        // Device switcher
        $('.spm-device-btn').on('click', function () {
            const device = $(this).data('device');
            switchDevice(device);
        });

        // Schedule type switching
        $('input[name="schedule-type"]').on('change', function () {
            const type = $(this).val();
            $('.spm-schedule-options').hide();

            if (type === 'daterange') {
                $('#schedule-daterange').show();
            } else if (type === 'daysofweek') {
                $('#schedule-daysofweek').show();
            } else if (type === 'manual') {
                $('#schedule-manual').show();
            }
        });
        // Timezone search
        const $timezoneSelect = $('#spm-timezone');
        const $allTimezoneOptions = $timezoneSelect.children().clone();

        $('#spm-timezone-search').on('keyup', function () {
            const value = $(this).val().toLowerCase();
            $timezoneSelect.empty();

            if (!value) {
                $timezoneSelect.append($allTimezoneOptions.clone());
                return;
            }

            $allTimezoneOptions.each(function () {
                const $optgroup = $(this);
                if ($optgroup.is('optgroup')) {
                    const $clonedGroup = $optgroup.clone();
                    $clonedGroup.empty();

                    let hasMatch = false;
                    $optgroup.children('option').each(function () {
                        const text = $(this).text().toLowerCase();
                        if (text.indexOf(value) > -1) {
                            $clonedGroup.append($(this).clone());
                            hasMatch = true;
                        }
                    });

                    if (hasMatch) {
                        $timezoneSelect.append($clonedGroup);
                    }
                } else {
                    const text = $(this).text().toLowerCase();
                    if (text.indexOf(value) > -1) {
                        $timezoneSelect.append($(this).clone());
                    }
                }
            });
        });
    }

    /**
     * Initialize modal
     */
    function initializeModal() {
        $('.spm-modal-close').on('click', function () {
            closeModal();
        });

        $('.spm-modal').on('click', function (e) {
            if ($(e.target).hasClass('spm-modal')) {
                closeModal();
            }
        });
    }

    /**
     * Open WordPress media uploader
     */
    function openMediaUploader(callback) {
        if (mediaUploader) {
            mediaUploader.off('select'); // Unbind previous select event
            mediaUploader.on('select', function () {
                const attachment = mediaUploader.state().get('selection').first().toJSON();
                callback(attachment.url);
            });
            mediaUploader.open();
            return;
        }

        mediaUploader = wp.media({
            title: 'Select Image',
            button: {
                text: 'Use this image'
            },
            multiple: false
        });

        mediaUploader.on('select', function () {
            const attachment = mediaUploader.state().get('selection').first().toJSON();
            callback(attachment.url);
        });

        mediaUploader.open();
    }

    /**
     * Add slide item to slider
     */
    function addSlideItem(url, link = '', schedule = {}) {
        const scheduleType = schedule.type || 'always';
        const startDate = schedule.start || '';
        const endDate = schedule.end || '';
        const customDisplay = scheduleType === 'custom' ? 'flex' : 'none';

        const slideHtml = `
            <div class="spm-slide-item">
                <div class="spm-slide-drag-handle" title="Drag to reorder">
                    <img src="${url}" class="spm-slide-preview">
                </div>
                <div class="spm-slide-inputs">
                    <input type="hidden" class="slide-url" value="${url}">
                    <input type="url" class="spm-input slide-link" placeholder="Link URL (optional)" value="${link}">
                    
                    <div class="spm-slide-schedule-row">
                        <select class="spm-input slide-schedule-type" style="width: auto;">
                            <option value="always" ${scheduleType === 'always' ? 'selected' : ''}>Always Show</option>
                            <option value="custom" ${scheduleType === 'custom' ? 'selected' : ''}>Schedule Dates</option>
                        </select>
                        <div class="spm-slide-dates" style="display: ${customDisplay}; gap: 5px; align-items: center;">
                            <input type="date" class="spm-input slide-start-date" value="${startDate}" placeholder="Start">
                            <span>to</span>
                            <input type="date" class="spm-input slide-end-date" value="${endDate}" placeholder="End">
                        </div>
                    </div>
                </div>
                <button type="button" class="spm-slide-remove">&times;</button>
            </div>
        `;

        const $slide = $(slideHtml);
        $('#spm-slides-container').append($slide);

        // Toggle date fields
        $slide.find('.slide-schedule-type').on('change', function() {
            if ($(this).val() === 'custom') {
                $(this).closest('.spm-slide-inputs').find('.spm-slide-dates').css('display', 'flex');
            } else {
                $(this).closest('.spm-slide-inputs').find('.spm-slide-dates').hide();
            }
        });

        // Remove slide
        $slide.find('.spm-slide-remove').on('click', function () {
            $(this).closest('.spm-slide-item').remove();
        });
    }

    /**
     * Load all popups
     */
    function loadPopups() {
        $.ajax({
            url: spmAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'spm_get_popups',
                nonce: spmAdmin.nonce
            },
            success: function (response) {
                if (response.success) {
                    allPopups = response.data;
                    renderPopups(response.data);
                    populateScheduleSelect(response.data);
                }
            }
        });
    }

    /**
     * Render popups grid
     */
    function renderPopups(popups) {
        const container = $('#spm-popups-list');

        if (popups.length === 0) {
            container.html('<div class="spm-loading">No popups created yet. Click "Create New Popup" to get started!</div>');
            return;
        }

        let html = '';
        popups.forEach(function (popup) {
            const settings = typeof popup.settings === 'string' ? JSON.parse(popup.settings) : popup.settings;
            const typeLabel = popup.type.charAt(0).toUpperCase() + popup.type.slice(1);
            const schedule = settings.schedule || { type: 'manual' };

            // Get schedule badge
            let scheduleBadge = '';
            let scheduleText = '';

            switch (schedule.type) {
                case 'always':
                    scheduleBadge = '<span class="spm-schedule-badge spm-badge-always"><span class="dashicons dashicons-yes-alt"></span> Always Active</span>';
                    break;
                case 'daterange':
                    const start = schedule.start_date || '';
                    const end = schedule.end_date || '';
                    scheduleBadge = `<span class="spm-schedule-badge spm-badge-daterange"><span class="dashicons dashicons-calendar"></span> ${start} to ${end}</span>`;
                    break;
                case 'daysofweek':
                    const days = schedule.days ? schedule.days.split(',') : [];
                    const dayNames = { 0: 'Sun', 1: 'Mon', 2: 'Tue', 3: 'Wed', 4: 'Thu', 5: 'Fri', 6: 'Sat' };
                    const dayLabels = days.map(d => dayNames[d]).join(', ');
                    scheduleBadge = `<span class="spm-schedule-badge spm-badge-days"><span class="dashicons dashicons-backup"></span> ${dayLabels}</span>`;
                    break;
                case 'manual':
                    scheduleBadge = '<span class="spm-schedule-badge spm-badge-manual"><span class="dashicons dashicons-calendar-alt"></span> Manual Calendar</span>';
                    break;
            }

            // Append timezone if set
            if (schedule.timezone) {
                // Shorten timezone for display if needed, but full name is usually fine
                // Maybe just show (Timezone)
                scheduleBadge += ` <span class="spm-schedule-timezone" style="color: #666; font-size: 0.9em;">(${schedule.timezone})</span>`;
            }

            html += `
                <div class="spm-popup-card" data-id="${popup.id}">
                    <div class="spm-popup-card-header">
                        <h3 class="spm-popup-card-title">${popup.name}</h3>
                        <span class="spm-popup-card-type">${typeLabel}</span>
                    </div>
                    ${scheduleBadge}
                    <div class="spm-popup-card-actions">
                        <button class="spm-btn spm-btn-primary spm-edit-popup" data-id="${popup.id}">
                            <span class="dashicons dashicons-edit"></span>
                            Edit
                        </button>
                        <button class="spm-btn spm-btn-danger spm-delete-popup" data-id="${popup.id}">
                            <span class="dashicons dashicons-trash"></span>
                            Delete
                        </button>
                    </div>
                </div>
            `;
        });

        container.html(html);

        // Edit popup
        $(document).on('click', '.spm-edit-popup', function (e) {
            e.preventDefault();
            e.stopPropagation();
            const popupId = $(this).data('id');
            editPopup(popupId);
        });

        // Delete popup
        $(document).on('click', '.spm-delete-popup', function (e) {
            e.preventDefault();
            e.stopPropagation();
            const popupId = $(this).data('id');
            if (confirm('Are you sure you want to delete this popup?')) {
                deletePopup(popupId);
            }
        });
    }

    /**
     * Save popup
     */
    function savePopup() {
        console.log('SPM: Save button clicked');
        const name = $('#spm-popup-name').val().trim();
        const type = $('input[name="popup-type"]:checked').val();

        if (!name) {
            alert('Please enter a popup name');
            return;
        }

        let content = '';
        const scheduleType = $('input[name="schedule-type"]:checked').val();
        const scheduleData = {
            type: scheduleType,
            timezone: $('#spm-timezone').val()
        };

        console.log('SPM: Basic data', { name, type, scheduleType });

        // Get schedule-specific data
        if (scheduleType === 'daterange') {
            const startDate = $('#spm-schedule-start').val();
            const endDate = $('#spm-schedule-end').val();

            if (!startDate || !endDate) {
                alert('Please select both start and end dates');
                return;
            }

            if (new Date(startDate) > new Date(endDate)) {
                alert('Start date must be before or equal to end date');
                return;
            }

            scheduleData.start_date = startDate;
            scheduleData.end_date = endDate;
        } else if (scheduleType === 'daysofweek') {
            const days = [];
            $('input[name="schedule-days"]:checked').each(function () {
                days.push($(this).val());
            });

            if (days.length === 0) {
                alert('Please select at least one day of the week');
                return;
            }

            scheduleData.days = days.join(',');
        }

        const settings = {
            close_bg: $('#spm-close-bg').val(),
            close_color: $('#spm-close-color').val(),
            animation: $('#spm-animation').val(),
            animation_duration: $('#spm-animation-duration').val(),
            trigger: $('#spm-trigger').val(),
            trigger_delay: $('#spm-trigger-delay').val(),
            trigger_scroll: $('#spm-trigger-scroll').val(),
            trigger_selector: $('#spm-trigger-selector').val(),
            responsive: $('#spm-responsive').is(':checked'),
            close_outside: $('#spm-close-outside').is(':checked'),
            max_width: $('#spm-max-width').val() === 'custom' ? $('#spm-custom-width').val() : $('#spm-max-width').val(),
            max_height: $('#spm-max-height').val() === 'custom' ? $('#spm-custom-height').val() : $('#spm-max-height').val(),
            content_fit: $('#spm-content-fit').val(),
            scale: $('#spm-scale').val(),
            schedule: scheduleData
        };

        // Get content based on type
        if (type === 'image') {
            content = $('#spm-image-url').val();
            if (!content) {
                alert('Please select an image');
                return;
            }
            settings.link_url = $('#spm-image-link').val();
        } else if (type === 'slider') {
            const slides = [];
            $('.spm-slide-item').each(function () {
                const $el = $(this);
                slides.push({
                    url: $el.find('.slide-url').val(),
                    link: $el.find('.slide-link').val(),
                    schedule: {
                        type: $el.find('.slide-schedule-type').val(),
                        start: $el.find('.slide-start-date').val(),
                        end: $el.find('.slide-end-date').val()
                    }
                });
            });

            console.log('SPM: Collected slides', slides);

            if (slides.length === 0) {
                alert('Please add at least one slide');
                return;
            }

            content = JSON.stringify(slides);
            settings.transition = $('#spm-slider-transition').val();
            settings.autoplay = $('#spm-slider-autoplay').is(':checked');
            settings.interval = $('#spm-slider-interval').val();
        } else if (type === 'html') {
            content = $('#spm-html-content').val();
            if (!content) {
                alert('Please enter HTML content');
                return;
            }
        }

        const popupData = {
            action: 'spm_save_popup',
            nonce: spmAdmin.nonce,
            popup_id: currentPopupId,
            name: name,
            type: type,
            content: content,
            settings: settings
        };

        console.log('SPM: Sending data', popupData);

        $.ajax({
            url: spmAdmin.ajaxurl,
            type: 'POST',
            data: popupData,
            success: function (response) {
                console.log('SPM: Response received', response);
                if (response.success) {
                    closeModal();
                    loadPopups();
                    alert('Popup saved successfully!');
                } else {
                    console.error('SPM: Save error', response);
                    alert('Error saving popup: ' + (response.data || 'Unknown error'));
                }
            },
            error: function (xhr, status, error) {
                console.error('SPM: AJAX error', status, error, xhr.responseText);
                alert('Server error occurred. Check console for details.');
            }
        });
    }

    /**
     * Edit popup
     */
    function editPopup(popupId) {
        const popup = allPopups.find(p => p.id == popupId);
        if (!popup) return;

        currentPopupId = popupId;
        resetPopupForm();

        const settings = typeof popup.settings === 'string' ? JSON.parse(popup.settings) : popup.settings;

        // Set basic fields
        $('#spm-popup-name').val(popup.name);
        $('input[name="popup-type"][value="' + popup.type + '"]').prop('checked', true).trigger('change');

        // Set content based on type
        if (popup.type === 'image') {
            $('#spm-image-url').val(popup.content);
            $('#spm-image-preview').html('<img src="' + popup.content + '">').addClass('active');
            $('#spm-image-link').val(settings.link_url || '');
        } else if (popup.type === 'slider') {
            const slides = JSON.parse(popup.content);
            slides.forEach(function (slide) {
                addSlideItem(slide.url, slide.link || '', slide.schedule || {});
            });
            $('#spm-slider-transition').val(settings.transition || 'fade');
            $('#spm-slider-autoplay').prop('checked', settings.autoplay !== false);
            $('#spm-slider-interval').val(settings.interval || 3000);
        } else if (popup.type === 'html') {
            $('#spm-html-content').val(popup.content);
        }

        // Set settings
        $('#spm-close-bg').val(settings.close_bg || '#21409a').trigger('change');
        $('#spm-close-color').val(settings.close_color || '#ffffff').trigger('change');
        $('#spm-animation').val(settings.animation || 'fade');
        $('#spm-animation-duration').val(settings.animation_duration || 500);
        $('#spm-trigger').val(settings.trigger || 'onload').trigger('change');
        $('#spm-trigger-delay').val(settings.trigger_delay || 3);
        $('#spm-trigger-scroll').val(settings.trigger_scroll || 50);
        $('#spm-trigger-selector').val(settings.trigger_selector || '');
        $('#spm-responsive').prop('checked', settings.responsive !== false);
        $('#spm-close-outside').prop('checked', settings.close_outside !== false);

        // Set size/scale settings
        $('#spm-max-width').val(settings.max_width || '90vw').trigger('change');
        $('#spm-max-height').val(settings.max_height || '90vh').trigger('change');
        $('#spm-custom-width').val('');
        $('#spm-custom-height').val('');
        $('#spm-content-fit').val(settings.content_fit || 'contain');
        $('#spm-scale').val(settings.scale || 100);

        // Set schedule settings
        const schedule = settings.schedule || { type: 'always' };
        $('input[name="schedule-type"][value="' + schedule.type + '"]').prop('checked', true).trigger('change');

        if (schedule.type === 'daterange') {
            $('#spm-schedule-start').val(schedule.start_date || '');
            $('#spm-schedule-end').val(schedule.end_date || '');
        } else if (schedule.type === 'daysofweek') {
            $('input[name="schedule-days"]').prop('checked', false);
            if (schedule.days) {
                const days = schedule.days.split(',');
                days.forEach(function (day) {
                    $('input[name="schedule-days"][value="' + day + '"]').prop('checked', true);
                });
            }
        }

        // Set timezone
        $('#spm-timezone').val(schedule.timezone || '').trigger('change');

        openModal('#spm-modal');
        $('#spm-modal-title').text('Edit Popup');
    }

    /**
     * Delete popup
     */
    function deletePopup(popupId) {
        $.ajax({
            url: spmAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'spm_delete_popup',
                nonce: spmAdmin.nonce,
                popup_id: popupId
            },
            success: function (response) {
                loadPopups();
                alert('Popup deleted successfully!');
            }
        });
    }

    /**
     * Initialize calendar
     */
    function initializeCalendar() {
        const calendarScript = spmAdmin.pluginUrl + 'admin/js/calendar.js';
        if (window.SPMCalendar) {
            window.SPMCalendar.init();
        }
    }

    /**
     * Populate schedule select dropdown
     */
    function populateScheduleSelect(popups) {
        const select = $('#spm-schedule-popup');
        select.empty().append('<option value="">-- Select a Popup --</option>');

        popups.forEach(function (popup) {
            select.append('<option value="' + popup.id + '">' + popup.name + '</option>');
        });
    }

    /**
     * Reset popup form
     */
    function resetPopupForm() {
        $('#spm-popup-form')[0].reset();
        $('#spm-popup-id').val('');
        $('#spm-image-preview').html('').removeClass('active');
        $('#spm-slides-container').empty();
        $('.spm-content-section').hide();
        $('#content-image').show();
        $('.spm-trigger-option').hide();
        $('.spm-schedule-options').hide();

        // Reset color pickers
        $('#spm-close-bg').val('#21409a').trigger('change');
        $('#spm-close-color').val('#ffffff').trigger('change');

        // Reset schedule type to "always"
        $('input[name="schedule-type"][value="always"]').prop('checked', true);
        $('input[name="schedule-days"]').prop('checked', false);
        $('#spm-schedule-start').val('');
        $('#spm-schedule-end').val('');
        $('#spm-timezone').val('').trigger('change');
        // Reset timezone search and visibility
        $('#spm-timezone-search').val('');
        $('#spm-timezone-search').trigger('keyup');
    }

    /**
     * Open modal
     */
    function openModal(modalId) {
        $(modalId).addClass('active');
        $('body').css('overflow', 'hidden');
    }

    /**
     * Close modal
     */
    function closeModal() {
        $('.spm-modal').removeClass('active');
        $('body').css('overflow', '');
    }

    /**
     * Show preview
     */
    function showPreview() {
        const type = $('input[name="popup-type"]:checked').val();
        const settings = {
            close_bg: $('#spm-close-bg').val(),
            close_color: $('#spm-close-color').val(),
            animation: $('#spm-animation').val(),
            max_width: $('#spm-max-width').val() === 'custom' ? $('#spm-custom-width').val() : $('#spm-max-width').val(),
            max_height: $('#spm-max-height').val() === 'custom' ? $('#spm-custom-height').val() : $('#spm-max-height').val(),
            content_fit: $('#spm-content-fit').val(),
            scale: $('#spm-scale').val()
        };

        let content = '';
        let popupHTML = '';

        // Build preview based on type
        if (type === 'image') {
            const imageUrl = $('#spm-image-url').val();
            if (!imageUrl) {
                alert('Please upload an image first');
                return;
            }
            content = '<img src="' + imageUrl + '" style="display: block; width: 100%; height: auto; object-fit: ' + settings.content_fit + ';">';
        } else if (type === 'slider') {
            const slides = [];
            $('.spm-slide-item').each(function () {
                slides.push($(this).find('.slide-url').val());
            });

            if (slides.length === 0) {
                alert('Please add at least one slide');
                return;
            }

            content = '<div style="position: relative;"><img src="' + slides[0] + '" style="display: block; width: 100%; height: auto; object-fit: ' + settings.content_fit + ';"></div>';
        } else if (type === 'html') {
            content = $('#spm-html-content').val();
            if (!content) {
                alert('Please enter HTML content');
                return;
            }
        }

        // Build popup HTML
        const maxWidth = settings.max_width || '90vw';
        const maxHeight = settings.max_height || '90vh';
        const scale = settings.scale || 100;
        const transform = scale != 100 ? 'transform: scale(' + (scale / 100) + ');' : '';

        popupHTML = `
            <div class="spm-popup-overlay" style="position: relative; display: flex; background: rgba(0, 0, 0, 0.5);">
                <div class="spm-popup-container" style="position: relative; max-width: ${maxWidth}; max-height: ${maxHeight}; ${transform} background: white; border-radius: 4px; margin: auto; overflow: hidden; box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);">
                    <button class="spm-close-btn" style="position: absolute; top: 10px; right: 10px; width: 40px; height: 40px; border: none; border-radius: 50%; font-size: 28px; cursor: pointer; background-color: ${settings.close_bg}; color: ${settings.close_color};">&times;</button>
                    <div class="spm-popup-content">
                        ${content}
                    </div>
                </div>
            </div>
        `;

        // Show preview modal
        $('#spm-preview-content').html(popupHTML);
        $('#spm-preview-modal').addClass('active');

        // Detect image orientation in preview
        setTimeout(function () {
            const previewImg = $('#spm-preview-content img').first();
            if (previewImg.length > 0) {
                const img = previewImg[0];
                if (img.complete) {
                    applyPreviewOrientation(img);
                } else {
                    previewImg.on('load', function () {
                        applyPreviewOrientation(this);
                    });
                }
            }
        }, 100);
    }

    function applyPreviewOrientation(img) {
        const width = img.naturalWidth || img.width;
        const height = img.naturalHeight || img.height;
        const container = $('#spm-preview-content .spm-popup-container');

        if (height > width) {
            container.addClass('spm-portrait').removeClass('spm-landscape');
        } else {
            container.addClass('spm-landscape').removeClass('spm-portrait');
        }
    }

    /**
     * Switch device view
     */
    function switchDevice(device) {
        $('.spm-device-btn').removeClass('active');
        $('.spm-device-btn[data-device="' + device + '"]').addClass('active');
        $('#spm-preview-frame').attr('data-device', device);

        // Update dimensions display
        const dimensions = {
            desktop: '1920 × 1080',
            tablet: '768 × 1024',
            mobile: '375 × 667'
        };

        $('#spm-device-dimensions').text(dimensions[device] || '');
    }

    // Make functions globally accessible
    window.SPMAdmin = {
        openModal: openModal,
        closeModal: closeModal,
        loadPopups: loadPopups,
        showPreview: showPreview,
        switchDevice: switchDevice
    };

})(jQuery);
