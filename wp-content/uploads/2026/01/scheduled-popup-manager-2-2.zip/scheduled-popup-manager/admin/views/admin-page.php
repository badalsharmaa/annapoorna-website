<?php
/**
 * Admin Page Template
 * Professional interface for HD Popup Manager
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="spm-admin-wrapper">
    <div class="spm-header">
        <div class="spm-header-content">
            <h1>
                <span class="spm-logo">HD</span>
                HD Popup Manager
            </h1>
            <p class="spm-tagline">Professional Popup Scheduling System</p>
        </div>
    </div>

    <div class="spm-tabs">
        <button class="spm-tab-btn active" data-tab="popups">
            <span class="dashicons dashicons-images-alt2"></span>
            Manage Popups
        </button>
        <button class="spm-tab-btn" data-tab="schedule">
            <span class="dashicons dashicons-calendar-alt"></span>
            Schedule Calendar
        </button>
        <button class="spm-tab-btn" data-tab="settings">
            <span class="dashicons dashicons-admin-settings"></span>
            Settings
        </button>
    </div>

    <!-- Popups Tab -->
    <div class="spm-tab-content active" id="tab-popups">
        <div class="spm-section">
            <div class="spm-section-header">
                <h2>Your Popups</h2>
                <button class="spm-btn spm-btn-primary" id="spm-create-popup">
                    <span class="dashicons dashicons-plus"></span>
                    Create New Popup
                </button>
            </div>

            <div class="spm-popups-grid" id="spm-popups-list">
                <div class="spm-loading">Loading popups...</div>
            </div>
        </div>
    </div>

    <!-- Schedule Tab -->
    <div class="spm-tab-content" id="tab-schedule">
        <div class="spm-section">
            <div class="spm-section-header">
                <h2>Popup Schedule Calendar</h2>
                <div class="spm-calendar-nav">
                    <button class="spm-btn spm-btn-secondary" id="spm-prev-month">
                        <span class="dashicons dashicons-arrow-left-alt2"></span>
                    </button>
                    <span class="spm-current-month" id="spm-current-month"></span>
                    <button class="spm-btn spm-btn-secondary" id="spm-next-month">
                        <span class="dashicons dashicons-arrow-right-alt2"></span>
                    </button>
                </div>
            </div>

            <div class="spm-calendar-container">
                <div id="spm-calendar"></div>
            </div>
        </div>
    </div>

    <!-- Settings Tab -->
    <div class="spm-tab-content" id="tab-settings">
        <div class="spm-section">
            <h2>Global Settings</h2>
            <div class="spm-settings-grid">
                <div class="spm-setting-item">
                    <label>Default Animation</label>
                    <select id="spm-default-animation">
                        <option value="fade">Fade In</option>
                        <option value="slideDown">Slide Down</option>
                        <option value="slideUp">Slide Up</option>
                        <option value="slideLeft">Slide Left</option>
                        <option value="slideRight">Slide Right</option>
                        <option value="zoom">Zoom In</option>
                        <option value="bounce">Bounce</option>
                    </select>
                </div>
                <div class="spm-setting-item">
                    <label>Default Trigger</label>
                    <select id="spm-default-trigger">
                        <option value="onload">On Page Load</option>
                        <option value="delay">After Delay</option>
                        <option value="scroll">On Scroll</option>
                        <option value="exit">Exit Intent</option>
                        <option value="click">On Element Click</option>
                    </select>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Popup Creation/Edit Modal -->
<div id="spm-modal" class="spm-modal">
    <div class="spm-modal-content">
        <div class="spm-modal-header">
            <h2 id="spm-modal-title">Create New Popup</h2>
            <button class="spm-modal-close">&times;</button>
        </div>

        <div class="spm-modal-body">
            <form id="spm-popup-form">
                <input type="hidden" id="spm-popup-id" value="">

                <div class="spm-form-group">
                    <label>Popup Name *</label>
                    <input type="text" id="spm-popup-name" class="spm-input" placeholder="e.g., Monday Special Offer" required>
                </div>

                <div class="spm-form-group">
                    <label>Popup Type *</label>
                    <div class="spm-type-selector">
                        <label class="spm-type-card">
                            <input type="radio" name="popup-type" value="image" checked>
                            <div class="spm-type-card-content">
                                <span class="dashicons dashicons-format-image"></span>
                                <span>Single Image</span>
                            </div>
                        </label>
                        <label class="spm-type-card">
                            <input type="radio" name="popup-type" value="slider">
                            <div class="spm-type-card-content">
                                <span class="dashicons dashicons-slides"></span>
                                <span>Image Slider</span>
                            </div>
                        </label>
                        <label class="spm-type-card">
                            <input type="radio" name="popup-type" value="html">
                            <div class="spm-type-card-content">
                                <span class="dashicons dashicons-editor-code"></span>
                                <span>Custom HTML</span>
                            </div>
                        </label>
                    </div>
                </div>

                <!-- Image Popup Content -->
                <div class="spm-content-section" id="content-image">
                    <div class="spm-form-group">
                        <label>Upload Image *</label>
                        <div class="spm-image-upload">
                            <button type="button" class="spm-btn spm-btn-secondary" id="spm-upload-image">
                                <span class="dashicons dashicons-cloud-upload"></span>
                                Choose Image
                            </button>
                            <div id="spm-image-preview" class="spm-image-preview"></div>
                        </div>
                        <input type="hidden" id="spm-image-url">
                    </div>
                    <div class="spm-form-group">
                        <label>Link URL (Optional)</label>
                        <input type="url" id="spm-image-link" class="spm-input" placeholder="https://example.com">
                        <small>Click on popup image will redirect to this URL</small>
                    </div>
                </div>

                <!-- Slider Popup Content -->
                <div class="spm-content-section" id="content-slider" style="display:none;">
                    <div class="spm-form-group">
                        <label>Slider Images *</label>
                        <button type="button" class="spm-btn spm-btn-secondary" id="spm-add-slide">
                            <span class="dashicons dashicons-plus"></span>
                            Add Slide
                        </button>
                        <div id="spm-slides-container" class="spm-slides-container"></div>
                    </div>

                    <div class="spm-form-row">
                        <div class="spm-form-group">
                            <label>Transition Effect</label>
                            <select id="spm-slider-transition" class="spm-input">
                                <option value="fade">Fade</option>
                                <option value="slide">Slide</option>
                                <option value="zoom">Zoom</option>
                                <option value="flip">Flip</option>
                            </select>
                        </div>
                        <div class="spm-form-group">
                            <label>Autoplay Interval (ms)</label>
                            <input type="number" id="spm-slider-interval" class="spm-input" value="3000" min="1000" step="500">
                        </div>
                    </div>

                    <div class="spm-form-group">
                        <label class="spm-checkbox">
                            <input type="checkbox" id="spm-slider-autoplay" checked>
                            <span>Enable Autoplay</span>
                        </label>
                    </div>
                </div>

                <!-- HTML Popup Content -->
                <div class="spm-content-section" id="content-html" style="display:none;">
                    <div class="spm-form-group">
                        <label>Custom HTML Content *</label>
                        <textarea id="spm-html-content" class="spm-textarea" rows="10" placeholder="Enter your custom HTML here..."></textarea>
                        <small>You can use HTML, CSS, and JavaScript</small>
                    </div>
                </div>

                <div class="spm-divider"></div>

                <!-- Appearance Settings -->
                <h3 class="spm-section-title">Appearance & Animation</h3>

                <div class="spm-form-row">
                    <div class="spm-form-group">
                        <label>Animation Effect</label>
                        <select id="spm-animation" class="spm-input">
                            <option value="fade">Fade In</option>
                            <option value="slideDown">Slide Down</option>
                            <option value="slideUp">Slide Up</option>
                            <option value="slideLeft">Slide Left</option>
                            <option value="slideRight">Slide Right</option>
                            <option value="zoom">Zoom In</option>
                            <option value="bounce">Bounce</option>
                            <option value="flipX">Flip Horizontal</option>
                            <option value="flipY">Flip Vertical</option>
                        </select>
                    </div>
                    <div class="spm-form-group">
                        <label>Animation Duration (ms)</label>
                        <input type="number" id="spm-animation-duration" class="spm-input" value="500" min="100" step="100">
                    </div>
                </div>

                <div class="spm-form-row">
                    <div class="spm-form-group">
                        <label>Close Button Background</label>
                        <input type="text" id="spm-close-bg" class="spm-color-picker" value="#21409a">
                    </div>
                    <div class="spm-form-group">
                        <label>Close Button Color</label>
                        <input type="text" id="spm-close-color" class="spm-color-picker" value="#ffffff">
                    </div>
                </div>

                <div class="spm-divider"></div>

                <!-- Size & Scale Settings -->
                <h3 class="spm-section-title">Size & Scale</h3>

                <div class="spm-form-row">
                    <div class="spm-form-group">
                        <label>Max Width</label>
                        <select id="spm-max-width" class="spm-input">
                            <option value="90vw">90% Viewport (Default)</option>
                            <option value="400px">400px (Small)</option>
                            <option value="600px">600px (Medium)</option>
                            <option value="800px">800px (Large)</option>
                            <option value="1000px">1000px (Extra Large)</option>
                            <option value="1200px">1200px (Full Width)</option>
                            <option value="custom">Custom...</option>
                        </select>
                    </div>
                    <div class="spm-form-group">
                        <label>Max Height</label>
                        <select id="spm-max-height" class="spm-input">
                            <option value="90vh">90% Viewport (Default)</option>
                            <option value="400px">400px (Small)</option>
                            <option value="600px">600px (Medium)</option>
                            <option value="800px">800px (Large)</option>
                            <option value="auto">Auto (No Limit)</option>
                            <option value="custom">Custom...</option>
                        </select>
                    </div>
                </div>

                <div class="spm-form-row" style="display:none;" id="custom-dimensions">
                    <div class="spm-form-group">
                        <label>Custom Width</label>
                        <input type="text" id="spm-custom-width" class="spm-input" placeholder="e.g., 750px or 80vw">
                    </div>
                    <div class="spm-form-group">
                        <label>Custom Height</label>
                        <input type="text" id="spm-custom-height" class="spm-input" placeholder="e.g., 500px or 70vh">
                    </div>
                </div>

                <div class="spm-form-row">
                    <div class="spm-form-group">
                        <label>Content Fit</label>
                        <select id="spm-content-fit" class="spm-input">
                            <option value="contain">Contain (Fit inside, maintain ratio)</option>
                            <option value="cover">Cover (Fill container)</option>
                            <option value="fill">Fill (Stretch to fit)</option>
                            <option value="scale-down">Scale Down (Only if larger)</option>
                        </select>
                    </div>
                    <div class="spm-form-group">
                        <label>Popup Scale (%)</label>
                        <input type="number" id="spm-scale" class="spm-input" value="100" min="50" max="150" step="5">
                        <small>Adjust overall popup size (50% - 150%)</small>
                    </div>
                </div>

                <div class="spm-divider"></div>

                <!-- Trigger Settings -->
                <h3 class="spm-section-title">Trigger Options</h3>

                <div class="spm-form-group">
                    <label>Popup Trigger</label>
                    <select id="spm-trigger" class="spm-input">
                        <option value="onload">On Page Load</option>
                        <option value="delay">After Delay</option>
                        <option value="scroll">On Scroll (%)</option>
                        <option value="exit">Exit Intent</option>
                        <option value="click">On Element Click</option>
                    </select>
                </div>

                <div class="spm-trigger-options">
                    <div class="spm-trigger-option" id="trigger-delay" style="display:none;">
                        <label>Delay (seconds)</label>
                        <input type="number" id="spm-trigger-delay" class="spm-input" value="3" min="0" step="0.5">
                    </div>
                    <div class="spm-trigger-option" id="trigger-scroll" style="display:none;">
                        <label>Scroll Percentage (%)</label>
                        <input type="number" id="spm-trigger-scroll" class="spm-input" value="50" min="0" max="100">
                    </div>
                    <div class="spm-trigger-option" id="trigger-click" style="display:none;">
                        <label>CSS Selector</label>
                        <input type="text" id="spm-trigger-selector" class="spm-input" placeholder=".my-button, #trigger-element">
                        <small>Enter CSS selector of element(s) that will trigger the popup</small>
                    </div>
                </div>

                <div class="spm-divider"></div>

                <!-- Scheduling Options -->
                <h3 class="spm-section-title">Scheduling</h3>

                <div class="spm-form-group">
                    <label>When should this popup be active?</label>
                    <div class="spm-schedule-type-selector">
                        <label class="spm-schedule-type-card">
                            <input type="radio" name="schedule-type" value="always" checked>
                            <div class="spm-schedule-type-content">
                                <span class="dashicons dashicons-yes-alt"></span>
                                <strong>Always Active</strong>
                                <small>Active indefinitely until disabled</small>
                            </div>
                        </label>
                        <label class="spm-schedule-type-card">
                            <input type="radio" name="schedule-type" value="daterange">
                            <div class="spm-schedule-type-content">
                                <span class="dashicons dashicons-calendar"></span>
                                <strong>Date Range</strong>
                                <small>Active between specific dates</small>
                            </div>
                        </label>
                        <label class="spm-schedule-type-card">
                            <input type="radio" name="schedule-type" value="daysofweek">
                            <div class="spm-schedule-type-content">
                                <span class="dashicons dashicons-backup"></span>
                                <strong>Specific Days</strong>
                                <small>Active on selected weekdays</small>
                            </div>
                        </label>
                        <label class="spm-schedule-type-card">
                            <input type="radio" name="schedule-type" value="manual">
                            <div class="spm-schedule-type-content">
                                <span class="dashicons dashicons-calendar-alt"></span>
                                <strong>Manual Calendar</strong>
                                <small>Schedule on specific dates</small>
                            </div>
                        </label>
                    </div>
                </div>

                <div class="spm-form-group">
                    <label>Timezone</label>
                    <input type="text" id="spm-timezone-search" class="spm-input" placeholder="Search timezone..." style="margin-bottom: 5px;">
                    <select id="spm-timezone" class="spm-input">
                        <option value="">WordPress Default</option>
                        <?php
                        $timezones = timezone_identifiers_list();
                        $grouped_timezones = array();

                        // Add Basic UTC offsets (-12 to +14)
                        $utc_offsets = array();
                        for ($i = -12; $i <= 14; $i++) {
                            $sign = $i < 0 ? '-' : '+';
                            $abs = abs($i);
                            // Format as UTC+05:00
                            $offset_str = sprintf('%s%02d:00', $sign, $abs);
                            $label = "UTC{$offset_str}";
                            // Use a fixed offset timezone identifier if available, or just the string
                            // Since PHP timezone identifiers like 'Etc/GMT+5' have opposite signs, 
                            // we will use the Manual Offset approach or try to map to Etc/GMT
                            // Note: Etc/GMT+5 is actually GMT-5. 
                            // So we will just use the string value and handle it in JS/PHP if needed, 
                            // but ideally we map it to something Valid or just let it be a string.
                            // For simplicity and to match user request "UTC According to hr delay", we use the label as value or a constructed ID.
                            // Let's use 'UTC' . $offset_str as the value. PHP's DateTimeZone might not like it unless it's a valid offset.
                            // But for storage it's fine.
                            $value = "UTC{$offset_str}"; 
                            $utc_offsets[$value] = $label;
                        }
                        
                        // Add to grouped timezones first
                        $grouped_timezones['Basic UTC'] = $utc_offsets;

                        foreach ($timezones as $timezone) {
                            $dt = new DateTime('now', new DateTimeZone($timezone));
                            $offset = $dt->format('P');
                            $parts = explode('/', $timezone);
                            
                            if (count($parts) > 1) {
                                $continent = $parts[0];
                                // Handle multi-part cities like Argentina/Buenos_Aires
                                $city = implode(' - ', array_slice($parts, 1));
                                $city = str_replace('_', ' ', $city);
                                $label = "(UTC{$offset}) {$city}";
                                
                                // Add San Jose mappings
                                if ($timezone === 'America/Los_Angeles') {
                                    $label .= ' - San Jose (US)';
                                }
                                if ($timezone === 'America/Costa_Rica') {
                                    $label .= ' - San Jose (CR)';
                                }
                                
                                $grouped_timezones[$continent][$timezone] = $label;
                            } else {
                                $label = "(UTC{$offset}) {$timezone}";
                                $grouped_timezones['Other'][$timezone] = $label;
                            }
                        }

                        foreach ($grouped_timezones as $continent => $cities) {
                            echo '<optgroup label="' . esc_attr($continent) . '">';
                            foreach ($cities as $value => $label) {
                                echo '<option value="' . esc_attr($value) . '">' . esc_html($label) . '</option>';
                            }
                            echo '</optgroup>';
                        }
                        ?>
                    </select>
                    <small>Select the timezone for this popup's schedule. Leave empty to use site default.</small>
                </div>

                <!-- Date Range Options -->
                <div class="spm-schedule-options" id="schedule-daterange" style="display:none;">
                    <div class="spm-form-row">
                        <div class="spm-form-group">
                            <label>Start Date *</label>
                            <input type="date" id="spm-schedule-start" class="spm-input">
                        </div>
                        <div class="spm-form-group">
                            <label>End Date *</label>
                            <input type="date" id="spm-schedule-end" class="spm-input">
                        </div>
                    </div>
                    <small>Popup will be active from start date to end date (inclusive)</small>
                </div>

                <!-- Days of Week Options -->
                <div class="spm-schedule-options" id="schedule-daysofweek" style="display:none;">
                    <div class="spm-form-group">
                        <label>Select Days</label>
                        <div class="spm-days-selector">
                            <label class="spm-day-checkbox">
                                <input type="checkbox" name="schedule-days" value="1">
                                <span>Mon</span>
                            </label>
                            <label class="spm-day-checkbox">
                                <input type="checkbox" name="schedule-days" value="2">
                                <span>Tue</span>
                            </label>
                            <label class="spm-day-checkbox">
                                <input type="checkbox" name="schedule-days" value="3">
                                <span>Wed</span>
                            </label>
                            <label class="spm-day-checkbox">
                                <input type="checkbox" name="schedule-days" value="4">
                                <span>Thu</span>
                            </label>
                            <label class="spm-day-checkbox">
                                <input type="checkbox" name="schedule-days" value="5">
                                <span>Fri</span>
                            </label>
                            <label class="spm-day-checkbox">
                                <input type="checkbox" name="schedule-days" value="6">
                                <span>Sat</span>
                            </label>
                            <label class="spm-day-checkbox">
                                <input type="checkbox" name="schedule-days" value="0">
                                <span>Sun</span>
                            </label>
                        </div>
                        <small>Popup will be active every week on selected days</small>
                    </div>
                </div>

                <!-- Manual Calendar Info -->
                <div class="spm-schedule-options" id="schedule-manual" style="display:none;">
                    <div class="spm-info-box">
                        <span class="dashicons dashicons-info"></span>
                        <p>After saving this popup, use the <strong>Schedule Calendar</strong> tab to assign it to specific dates.</p>
                    </div>
                </div>

                <div class="spm-divider"></div>

                <h3 class="spm-section-title">Additional Options</h3>

                <div class="spm-form-group">
                    <label class="spm-checkbox">
                        <input type="checkbox" id="spm-responsive" checked>
                        <span>Enable Responsive Design (Auto-adjust for mobile)</span>
                    </label>
                </div>

                <div class="spm-form-group">
                    <label class="spm-checkbox">
                        <input type="checkbox" id="spm-close-outside" checked>
                        <span>Close on outside click</span>
                    </label>
                </div>
            </form>
        </div>

        <div class="spm-modal-footer">
            <button type="button" class="spm-btn spm-btn-secondary spm-modal-close">Cancel</button>
            <button type="button" class="spm-btn" id="spm-preview-popup" style="background: #17a2b8; color: white; margin-right: auto;">
                <span class="dashicons dashicons-visibility"></span>
                Preview
            </button>
            <button type="button" class="spm-btn spm-btn-primary" id="spm-save-popup">Save Popup</button>
        </div>
    </div>
</div>

<!-- Schedule Assignment Modal -->
<div id="spm-schedule-modal" class="spm-modal">
    <div class="spm-modal-content spm-modal-small">
        <div class="spm-modal-header">
            <h2>Assign Popup to Date</h2>
            <button class="spm-modal-close">&times;</button>
        </div>

        <div class="spm-modal-body">
            <div class="spm-form-group">
                <label>Select Popup</label>
                <select id="spm-schedule-popup" class="spm-input">
                    <option value="">-- Select a Popup --</option>
                </select>
            </div>
            <input type="hidden" id="spm-schedule-date">
        </div>

        <div class="spm-modal-footer">
            <button type="button" class="spm-btn spm-btn-secondary spm-modal-close">Cancel</button>
            <button type="button" class="spm-btn spm-btn-primary" id="spm-save-schedule">Assign</button>
        </div>
    </div>
</div>

<!-- Preview Modal -->
<div id="spm-preview-modal" class="spm-modal">
    <div class="spm-modal-content spm-modal-large">
        <div class="spm-modal-header">
            <h2>Popup Preview</h2>
            <button class="spm-modal-close">&times;</button>
        </div>

        <div class="spm-preview-controls">
            <button class="spm-device-btn active" data-device="desktop">
                <span class="dashicons dashicons-desktop"></span>
                Desktop
            </button>
            <button class="spm-device-btn" data-device="tablet">
                <span class="dashicons dashicons-tablet"></span>
                Tablet
            </button>
            <button class="spm-device-btn" data-device="mobile">
                <span class="dashicons dashicons-smartphone"></span>
                Mobile
            </button>
            <span class="spm-device-dimensions" id="spm-device-dimensions">1920 × 1080</span>
        </div>

        <div class="spm-preview-container">
            <div class="spm-preview-frame" id="spm-preview-frame" data-device="desktop">
                <div id="spm-preview-content"></div>
            </div>
        </div>

        <div class="spm-modal-footer">
            <button type="button" class="spm-btn spm-btn-secondary spm-modal-close">Close Preview</button>
        </div>
    </div>
</div>
